import React from 'react';
import { MdOutlineModeEdit, MdDeleteForever } from 'react-icons/md';

function Exercise({ exercises, onDelete, onEdit }) {
    return(
        <tr>
            <td>{exercises.name}</td>
            <td>{exercises.reps}</td>
            <td>{exercises.weight}</td>
            <td>{exercises.unit}</td>
            <td>{exercises.date}</td>
            <td><MdOutlineModeEdit onClick={ () => onEdit(exercises)}/></td>
            <td><MdDeleteForever onClick={ () => onDelete(exercises._id)}/></td>
        </tr>
    );
}

export default Exercise;