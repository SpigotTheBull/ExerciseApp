import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './pages/HomePage';
import CreateExercisePage from './pages/CreateExercisePage';
import EditExercisePage from './pages/EditExercisePage';
import { useState } from 'react';

function App() {
  const [ exerciseToEdit, setExerciseToEdit ] = useState();

  return (
    <div className="App">
      <Router>
        <div className="App-header">
          <Routes>
            <Route exact={true} path="/" element={<HomePage setExerciseToEdit={setExerciseToEdit} />} />
            <Route path="/create-exercise" element={<CreateExercisePage />} />
            <Route path="/edit-exercise" element={<EditExercisePage exerciseToEdit={exerciseToEdit} />} />
          </Routes>
        </div>
      </Router>
    </div>
  );
}

export default App;
